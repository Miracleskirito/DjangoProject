create definer = root@localhost trigger track_version_after_insert
    after insert
    on blind_box_items
    for each row
BEGIN
    -- 使用INSERT ... ON DUPLICATE KEY UPDATE实现智能更新
    INSERT INTO series_version_tracker (series_id, latest_version)
    VALUES (NEW.series_id, NEW.version)
    ON DUPLICATE KEY UPDATE 
        latest_version = IF(
            -- 版本比较逻辑（按字符串排序）
            NEW.version > latest_version, 
            NEW.version, 
            latest_version
        ),
        last_updated = IF(
            NEW.version > latest_version, 
            CURRENT_TIMESTAMP, 
            last_updated
        );
END;

