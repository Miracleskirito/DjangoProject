create definer = root@localhost trigger track_version_after_update
    after update
    on blind_box_items
    for each row
BEGIN
    -- 当version和series_id字段发生变更时触发
    IF OLD.version <> NEW.version OR OLD.series_id <> NEW.series_id THEN
        INSERT INTO series_version_tracker (series_id, latest_version)
        VALUES (NEW.series_id, NEW.version)
        ON DUPLICATE KEY UPDATE 
            latest_version = IF(NEW.version > latest_version, NEW.version, latest_version),
            last_updated = IF(NEW.version > latest_version, CURRENT_TIMESTAMP, last_updated);
    END IF;
END;

