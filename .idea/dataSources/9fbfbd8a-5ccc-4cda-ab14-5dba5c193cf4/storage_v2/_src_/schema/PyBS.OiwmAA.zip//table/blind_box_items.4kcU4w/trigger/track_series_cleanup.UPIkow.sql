create definer = root@localhost trigger track_series_cleanup
    after delete
    on blind_box_items
    for each row
BEGIN
    DECLARE remaining_count INT DEFAULT -1;
    
    -- 检查剩余物品数量
    SELECT COUNT(*) INTO remaining_count 
    FROM blind_box_items 
    WHERE series_id = OLD.series_id;

    -- 自动清理逻辑
    IF remaining_count = 0 THEN
        DELETE FROM series_version_tracker 
        WHERE series_id = OLD.series_id;
    END IF;
END;

